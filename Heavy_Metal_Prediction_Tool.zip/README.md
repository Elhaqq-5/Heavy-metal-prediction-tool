# Heavy Metal Prediction and Analysis Tool

This React project predicts heavy metal concentrations in soil (Cd, Cr, Cu, Ni, Pb, Zn) based on soil parameters.

## Input Parameters
- Organic Matter (%)
- Soil pH
- Cation Exchange Capacity (meq/100g)

## Output
- Mock AI-based predictions of heavy metal levels
- Visualized using charts

## How to Use
1. Enter soil parameters.
2. Click Predict.
3. View predicted metal levels.